interface ProductToOrderInterface {
  id: number;
  name: string;
  salePrice: number;
  quantity: number;
  description: string;
}

export default ProductToOrderInterface;
