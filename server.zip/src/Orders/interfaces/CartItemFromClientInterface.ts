interface CartItemFromClientInterface {
  productId: number;
  name: string;
  salePrice: string;
  quantity: number;
  description: string;
}

export default CartItemFromClientInterface;
