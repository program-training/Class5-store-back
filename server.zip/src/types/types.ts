import ServerError from "../utils/ServerError";

export type ErrorType = ServerError | Error | string;
