export const getBanner = async () => {
  return "hello from banners";
};
